// 导入express

const express=require('express')
const { append } = require('express/lib/response')

const router=express.Router()

// 导入路由

const reserve=require('../router_handler/reserve')


// 新增接口

router.post('/add',reserve.add)
// 更新接口
router.put('/up',reserve.up)

// 查询接口
router.post('/query',reserve.query)

module.exports = router