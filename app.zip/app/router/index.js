// 导入express

const express=require('express')

const router=express.Router()
// 1. 导入验证表单数据的中间件
const expressJoi = require('@escook/express-joi')
// 2. 导入需要的验证规则对象
const { reg_login_schema } = require('../schema/index')
// 导入路由

const index=require('../router_handler/index')

// 登录接口

router.post('/login',index.login)
// 注册接口
router.post('/reg',expressJoi(reg_login_schema),index.reg)

module.exports = router