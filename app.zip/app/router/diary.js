// 导入express

const express=require('express')

const router=express.Router()

// 导入路由

const diary=require('../router_handler/diary')


// 日记新增接口

router.post('/add',diary.add)
// 日记新增接口

router.put('/updiary',diary.updiary)
//日记查询接口

router.post('/query',diary.query)


module.exports = router