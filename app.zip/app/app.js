// 导入express
const express=require('express')
// 导入body 解析
var bodyParser = require('body-parser')
// 导入 cors 中间件
const cors = require('cors')
//导入 token解析包
const expressJWT= require('express-jwt')
const app=express()

// 导入token密钥
const config =require('./config.js')
// 导入logs包
require('./logs/index.js')
global.log = require('./logs/index.js').logger;
httpLogger = require('./logs/index.js').httpLogger;
app.use(httpLogger);
const joi = require('joi')


app.use((req,res,next)=>{

  req.rd=(data=null)=>{
       log.info({'method':req.method,'url':req.originalUrl,'请求参数':req.body},
       "请求返回",
       {'status':data.status,
       'msg':data.msg,
       ...data.data
     });
     }
   res.cc=(err,status=1,data=null)=>{
     const ressend={
       status,
       msg:err instanceof Error ? err.message :err,
       data
     }
    
     if(status===1){
       log.error({"name":'请求返回',ressend });
     }else{
       req.rd(ressend)
     }
   
     res.send(ressend)
   }
   next()
 })
// 将 cors 注册为全局中间件
app.use(cors())
app.set('x-powered-by',false) 
// 配置解析 配置解析 application/x-www-form-urlencoded 格式的表单数据的中间件：
app.use(express.urlencoded({ extended: true }))
app.use(bodyParser.json())

// z在路由之前配置解析token
// 使用 .unless({ path: [/^\/api\//] }) 指定哪,些接口不需要进行 Token 的身份认证
// app.use(expressJWT({ secret: config.jwtkey }).unless({ path: [/^\/api\//] }))

// 导入路由
const indexrouter = require('./router/index')

// 注册为全局
app.use('/api', indexrouter)


// 导入路由
const diary = require('./router/diary')

// 注册为全局
app.use('/apis', diary)

// 导入路由
const reserve = require('./router/reserve')

// 注册为全局
app.use('/reserve', reserve)
// 错误中间件
// app.use(function (err, req, res, next) {
//   // // 数据验证失败
//   if (err instanceof joi.ValidationError) return res.cc(err)
//   // 未知错误
//     // 捕获身份认证失败的错误
//     if (err.name === 'UnauthorizedError') return res.cc('身份认证失败！')
//   res.cc(err)

// })


app.listen(3000,()=>{
  console.log('启动成功');
})