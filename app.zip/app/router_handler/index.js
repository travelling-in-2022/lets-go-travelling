// 导入数据库操作文件
const db = require('../db/index')

var md5 = require('md5')
// 用这个包来生成 Token 字符串
const jwt = require('jsonwebtoken')
// 导入token密钥
const config =require('../config')

exports.login= (req,res)=>{
  let sql =`SELECT * FROM t_bd_user WHERE user=? and pwd =?`
   db.query(sql,[req.body.user,md5(req.body.pwd)],(err, results,fields)=>{
    if (err) {
      return res.cc(err)
    }
    if (results.length === 1) {
      console.log(results);
      const user={...results[0],pwd:''}
      const tokenstr= jwt.sign(user,config.jwtkey,{expiresIn:'4H'})
      console.log(tokenstr)
      return res.send({
        status:0,
        msg:'登录成功', 
        data:{token:'Bearer '+tokenstr}
      })
     // res.send({ status: 0, msg: '登录成功'{"token":'Bearer '+tokenstr}})
      // res.cc('登录成功',0,{token:'Bearer '+tokenstr})
    } else {
      return res.cc('请检查账号密码验证码')
    }
   })
  }

  // 注册接口 密码进行md5 加密
  exports.reg= (req,res)=>{
    let sql =`  INSERT INTO t_bd_user ( user, pwd )
    VALUES
      ( ?, ? )`
     db.query(sql,[req.body.user,md5(req.body.pwd)],(err, results,fields)=>{
      //  req.rd()
       if(err){
         res.cc(err)
         console.log(err)
       }else{
         // 返回结果
         res.cc('注册成功',0,{results})
        console.log(results);
       }
     })
    }


