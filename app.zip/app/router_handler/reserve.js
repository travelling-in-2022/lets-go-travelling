// 导入数据库操作文件
const db = require('../db/index')



  // 旅行新增
  exports.add= (req,res)=>{
    let sql =`INSERT INTO t_bd_reserve  ( oper_data,dest, people, start_date, end_date )
    VALUES
      (SYSDATE(), ?,?,?,? );
    `
    let body=req.body
console.log(body);
    let ins=[
      body.dest,// 目的地
      body.people,// 同行人数
      body.start_date,// start_date
      body.end_date
    ]
     db.query(sql,ins,(err, results,fields)=>{
      //  req.rd()
       if(err){
         res.cc(err)
         console.log(err)
       }else{
         // 返回结果
         res.cc('处理成功',0,{results})
        console.log(results);
       }
     })
    }

     // 旅行更新
  exports.up= (req,res)=>{
    let sql =`UPDATE t_bd_reserve
    SET oper_data = SYSDATE(),
    dest = ?,
    people = ?,
    start_date = ?,
    end_date = ?
    WHERE
      id = ?
    `
    let body=req.body

    let ins=[
      body.dest,// 目的地
      body.people,// 同行人数
      body.start_date,// start_date
      body.end_date,
      body.id// id
    ]
     db.query(sql,ins,(err, results,fields)=>{
      //  req.rd()
       if(err){
         res.cc(err)
         console.log(err)
       }else{
         // 返回结果
         res.cc('处理成功',0,{results})
        console.log(results);
       }
     })
    }

     // 旅行新增
  exports.query= (req,res)=>{
    let sql =`select * from t_bd_reserve`
    let body=req.body

     db.query(sql,(err, results,fields)=>{
      //  req.rd()
       if(err){
         res.cc(err)
         console.log(err)
       }else{
         // 返回结果
         res.cc('处理成功',0,{results})
        console.log(results);
       }
     })
    }