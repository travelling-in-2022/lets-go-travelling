// 导入数据库操作文件
const db = require('../db/index')








  // 日记新增接口
  exports.add= (req,res)=>{
    let sql =`INSERT INTO t_bd_diary  (diary,time) VALUES (?,	SYSDATE())`
    console.log(req.body.disry);
     db.query(sql,req.body.disry,(err, results,fields)=>{
      //  req.rd()
       if(err){
         res.cc(err)
         console.log(err)
       }else{
         // 返回结果
         res.cc('处理成功',0,{results})
        console.log(results);
       }
     })
    }

      // 日记更新接口
  exports.updiary= (req,res)=>{
    let sql =`   UPDATE t_bd_diary  SET diary = ? WHERE id = ?`
     db.query(sql,[req.body.disry,req.body.id],(err, results,fields)=>{
      //  req.rd()
       if(err){
         res.cc(err)
         console.log(err)
       }else{
         // 返回结果
         res.cc('处理成功',0,{results})
        console.log(results);
       }
     })
    }

          // 日记更新接口
  exports.query= (req,res)=>{
    let sql =`select * from t_bd_diary `
     db.query(sql,(err, results,fields)=>{
      //  req.rd()
       if(err){
         res.cc(err)
         console.log(err)
       }else{
         // 返回结果
         res.cc('处理成功',0,{results})
        console.log(results);
       }
     })
    }


  
