// 设置token 密钥

module.exports={
  jwtkey:'^-^'
}