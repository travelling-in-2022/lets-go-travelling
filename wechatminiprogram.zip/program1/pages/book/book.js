// pages/book/book.js
const util = require('../../utils/util')
Page({

  /**
   * 页面的初始数据
   */
  data: {
    endDateTime: util.formatTime(Date.now(),'yyyy年mm月dd日 HH时MM分ss秒'),
    startDateTime: util.formatTime(Date.now(),'yyyy年mm月dd日 HH时MM分ss秒'),
    destination:'',
    people_number:'',
  },
  placeInput(e){
    const {value}=e.detail
    this.setData ({
      destination: value
    });
  },
  numberInput(e){
    const {value}=e.detail
    this.setData ({
      people_number: value
    });
  },
  startDateTimeChange(e) {
    this.setData({
      startDateTime: e.detail.dateString
    })
  },
  endDateTimeChange(e) {
    this.setData({
      endDateTime: e.detail.dateString
    })
  },

  play:function(e){
    console.log(this.data)
    var dest=this.data.destination
    var people=this.data.people_number
    var start_date=this.data.startDateTime
    var end_date=this.data.endDateTime
    wx.request({
      //请求方式(大小写皆可，不写默认为GET请求)
      method:'POST',
      //服务器接口地址
      url:'http://127.0.0.1:3000/reserve/add',
      //data表示请求的参数
      data:{
        dest,
        people,
        start_date,
        end_date
      },
      //接口调用成功的回调函数
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      //res表示服务器响应信息
      success:function(res){
          console.log(res)
      }
    })
  },

  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {

  },

  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {

  },

  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {

  },

  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {

  },

  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {

  },

  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {

  },

  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {

  },

  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {

  },

})
