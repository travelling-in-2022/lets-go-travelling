var amapFile = require('../../libs/amap-wx.130');//如：..­/..­/libs/amap-wx.js

Page({
    data:{
        weather:{}
    },
  onLoad: function() {
    var that = this;
    var myAmapFun = new amapFile.AMapWX({key:'c31d64a77513e0c091051433435b3f76'});
    myAmapFun.getWeather({
      success: function(data){
        //成功回调
        that.setData({
            weather: data
          });
  
      },
      fail: function(info){
        //失败回调
        console.log(info)
      }
    })
  }
})