Page({
    data:{
        aimText:"",//输入的目的地
        newArry:[],//将本次搜索的目的地添加到历史记录中
        aimList:true,//搜索到的目的地
        history:false,//开始时不显示
        historyArry:[],//历史记录
        searchRes:false,//搜索到的列表
        noneview:false,//未找到
        cityList: [
            //0、昆明
            {
              //城市编号
              City_id: 1,
              //城市名称
              City_name: "昆明",
              status: 0,
              // 背景小图
              imgSrc:"../../images/p-1.jpg",
              // 背景大图
              bigimgSrc:"../../images/p-2.jpg",
              //推荐路线
              Reference: [{
                  Ref_id: 1,
                  Ref_cont: "茶马花街——西山风景区——海埂公园——海埂大坝——金鸡碧马坊——南屏街",
                },
                {
                  Ref_id: 2,
                  Ref_cont: "云南大学东陆校区——翠湖公园——陆军讲武堂旧址——西园路/文化巷",
                },
                {
                  Ref_id: 3,
                  Ref_cont: "云南省博物馆新馆——官渡古镇——大观篆新农贸市场",
                }
              ],
              //旅游景点
              Places: [{
                  Place_id: 1,
                  Place_name: "滇池",
                  Place_tickets: "免费",
                  Place_traffic: "24/44/73路海埂公园",
                  Place_lightspot: "滇池又名昆明湖，是云南最大的淡水湖，形似玄月，山水环抱，天光云影。",
                  Place_tips: null,
                  Place_time: "全天",
                },
                {
                  Place_id: 2,
                  Place_name: "西山风景区",
                  Place_tickets: "石窟景区40元",
                  Place_traffic: "民族村附近可乘坐高空缆车直达西山龙门，单程35元。",
                  Place_lightspot: "西山又称碧鸡山，远远望去，西山如一女子躺卧于滇池岸边，有'西山睡美人'之称。",
                  Place_tips: null,
                  Place_time: "8:00——17:00",
                },
                {
                  Place_id: 3,
                  Place_name: "民族村",
                  Place_tickets: "90元",
                  Place_traffic: "24/44/73路等云南民族村站",
                  Place_lightspot: "以自然村落式的民居建筑为主，园内有傣族、白族、彝族、景颇族等25个少数民族村寨及各种表演",
                  Place_tips: null,
                  Place_time: "8:30——17:30",
                },
              ],
              //美食
              Foods: [{
                  Foods_id: 1,
                  Foods_name: "米线",
                  Foods_price: "10元",
                  Foods_place: "建新园、桥香园、铁朋小锅米线、娘子情过桥米线、小人桥豆花米线、新迎传统豆花米线等。",
                },
                {
                  Foods_id: 2,
                  Foods_name: "饵块/饵丝",
                  Foods_price: "10元",
                  Foods_place: "英凤烧饵块、文山荷鲜居、云平风味园。",
                },
                {
                  Foods_id: 3,
                  Foods_name: "汽锅鸡",
                  Foods_price: "88元",
                  Foods_place: "福照楼、云海肴云南菜。",
                },
              ]
            },
            //1、郑州
            {
              //城市编号
              City_id: 1,
              //城市名称
              City_name: "郑州",
              status: 0,
              imgSrc:"../../images/p-1.jpg",
              // 背景大图
              bigimgSrc:"../../images/p-2.jpg",
        
              //推荐路线
              Reference: [{
                  Ref_id: 1,
                  Ref_cont: "二七塔——德化街——河南博物院——健康路",
                },
                {
                  Ref_id: 2,
                  Ref_cont: "人民公园——会展中心玉米楼——龙湖公共艺术中心",
                },
                {
                  Ref_id: 3,
                  Ref_cont: "嵩山少林寺一日游(少林寺——塔林——栈道——三皇寨)",
                }
              ],
              //旅游景点
              Places: [{
                  Place_id: 1,
                  Place_name: "二七纪念塔",
                  Place_tickets: "免费(身份证安检参观)",
                  Place_traffic: "2/17/k805公交/地铁一号线二七广场站",
                  Place_lightspot: "位于二七广场,是为纪念1923年京汉铁路工人大罢工而修建的纪念性的建筑",
                  Place_tips: null,
                  Place_time: "9:00-17:00",
                },
                {
                  Place_id: 2,
                  Place_name: "河南省博物馆",
                  Place_tickets: "免费",
                  Place_traffic: "乘坐B1/83/96路等公交可到达",
                  Place_lightspot: "创建于1927年,馆藏文物多达14万件,是中国最值得去的博物馆之一",
                  Place_tips: null,
                  Place_time: "9:00-17:30(周一闭馆)",
                },
                {
                  Place_id: 3,
                  Place_name: "CBD会展中心/玉米楼(千禧广场)",
                  Place_tickets: "免费",
                  Place_traffic: "地铁一号线",
                  Place_lightspot: "郑州新地标,夜景很美",
                  Place_tips: null,
                  Place_time: "全天",
                },
                {
                  Place_id: 4,
                  Place_name: "黄河游览区",
                  Place_tickets: "48元；游乐设施:电瓶车20/索道50/滑道20元",
                  Place_traffic: "游1、游16路公交车直达景区,票价5元",
                  Place_lightspot: "位于郑州市西北20公里处黄河之滨,地上'悬河'的起点,也是黄河中下游的分界线,景区有炎黄二帝雕像、五龙峰、岳山寺、黄河索道等景点",
                  Place_tips: null,
                  Place_time: "6:00-20:00",
                },
              ],
              //美食
              Foods: [{
                  Foods_id: 1,
                  Foods_name: "烩面",
                  Foods_price: "10-13元",
                  Foods_place: "萧记三鲜烩面、合记烩面、四厂烩面、西三烩面",
                },
                {
                  Foods_id: 2,
                  Foods_name: "胡辣汤",
                  Foods_price: "15元",
                  Foods_place: "方中山胡辣汤(顺河路店）、逍遥镇胡辣汤、高老大牛排胡辣汤(嵩山南路249-36)",
                },
                {
                  Foods_id: 3,
                  Foods_name: "烩羊肉",
                  Foods_price: "null",
                  Foods_place: "三厂老胡家烩羊肉、刘记羊肉汤"
                },
              ]
            },
            //2、呼伦贝尔
            {
              //城市编号
              City_id: 2,
              //城市名称
              City_name: "呼伦贝尔",
              status: 0,
              imgSrc:"../../images/p-1.jpg",
              // 背景大图
              bigimgSrc:"../../images/p-2.jpg",
              //推荐路线
              Reference: [{
                  Ref_id: 1,
                  Ref_cont: "海拉尔——金帐汗——莫日格勒河——额尔古纳——白桦林景区——上户林/下户林——恩和俄罗斯民族乡",
                },
                {
                  Ref_id: 2,
                  Ref_cont: "恩和——哈乌尔景区——9卡8卡7卡——太极图——室韦——额尔古纳河——临江——室韦",
                },
                {
                  Ref_id: 3,
                  Ref_cont: "临江——老鹰嘴——月亮泡——太平——莫尔道嘎森林公园——莫尔道嘎——龙岩山",
                },
                {
                  Ref_id: 4,
                  Ref_cont: "根河高速——额尔古纳——亚洲第一湿地——额市六队牧民家里挤牛奶——黑山头",
                },
                {
                  Ref_id: 5,
                  Ref_cont: "黑山头(骑马)——三十三湿地——186彩带河——扎区博物馆——猛犸象公园——满洲里——套娃广场——国门",
                },
                {
                  Ref_id: 6,
                  Ref_cont: "满洲里——呼伦湖——巴尔虎蒙古部落——扎赉诺尔——伊和乌拉山——呼和诺尔草原——陈巴尔虎旗狼岛",
                }
              ],
              //旅游景点
              Places: [{
                  Place_id: 1,
                  Place_name: "呼伦贝尔大草原",
                  Place_tickets: "免费",
                  Place_traffic: "null",
                  Place_lightspot: "呼伦贝尔大草原无限草原风光壮美而辽阔。因为几乎没有受到任何污染,所以又有'最纯洁草原'之称 ",
                  Place_tips: null,
                  Place_time: "全天",
                },
                {
                  Place_id: 2,
                  Place_name: "白桦林景区",
                  Place_tickets: "55元",
                  Place_traffic: "null",
                  Place_lightspot: "电影《断片》取景拍摄地,成片的树林,笔直的树干,葱茏的树叶和地上半尺高的草丛,抚摸白桦林,仿佛在与一种无言的生命倾诉",
                  Place_tips: null,
                  Place_time: "8:00-18:00",
                },
                {
                  Place_id: 3,
                  Place_name: "敖鲁古雅使鹿部落景区",
                  Place_tickets: "80元",
                  Place_traffic: "null",
                  Place_lightspot: "敖鲁古雅使鹿部落生活着中国唯一以饲养驯鹿为生的民族——鄂温克族",
                  Place_tips: null,
                  Place_time: "8:00-17:30",
                },
                {
                  Place_id: 4,
                  Place_name: "额尔古纳湿地公园",
                  Place_tickets: "60元",
                  Place_traffic: "null",
                  Place_lightspot: "蜿蜒曲折的河流流淌在湿地中央,天然景色与人文景色交相辉映,形成一道独特的亮丽风景线",
                  Place_tips: null,
                  Place_time: "全天",
                },
      
              ],
              //美食
              Foods: [{
                  Foods_id: 1,
                  Foods_name: "烤羊腿",
                  Foods_price: "null",
                  Foods_place: "呼伦贝尔",
                },
                {
                  Foods_id: 2,
                  Foods_name: "奶茶",
                  Foods_price: "4元",
                  Foods_place: "蒙古族传统特饮",
                },
                {
                  Foods_id: 3,
                  Foods_name: "手扒肉",
                  Foods_price: "null",
                  Foods_place: "蒙古族传统美食"
                },
                {
                  Foods_id: 4,
                  Foods_name: "俄罗斯列巴",
                  Foods_price: "null",
                  Foods_place: "俄罗斯面包,口感酥脆软绵"
                },
              ]
            },
            //3、苏州
            {
              //城市编号
              City_id: 3,
              //城市名称
              City_name: "苏州",
              status: 0,
              imgSrc:"../../images/p-1.jpg",
              // 背景大图
              bigimgSrc:"../../images/p-2.jpg",
              //推荐路线
              Reference: [{
                  Ref_id: 1,
                  Ref_cont: "苏州博物馆——拙政园——平江路——七里山塘街",
                },
                {
                  Ref_id: 2,
                  Ref_cont: "虎丘——诚品书店——苏州中心",
                },
                {
                  Ref_id: 3,
                  Ref_cont: "周庄/同里古镇一日游/阳澄湖吃大闸蟹",
                },
              ],
              //旅游景点
              Places: [{
                  Place_id: 1,
                  Place_name: "拙政园",
                  Place_tickets: "旺季80元；淡季60元",
                  Place_traffic: "地铁4号线北寺塔站/游1路苏州博物馆下",
                  Place_lightspot: "江南古典园林的代表,中国四大明园之一",
                  Place_tips: null,
                  Place_time: "7:30-18:00",
                },
                {
                  Place_id: 2,
                  Place_name: "苏州博物馆",
                  Place_tickets: "免费",
                  Place_traffic: "地铁一号线临顿路站",
                  Place_lightspot: "一座集现代化馆舍建筑、古建筑与创新山水园林三位一体的综合性博物馆",
                  Place_tips: "每天8:00-23:00苏博官网预约,苏博门票比较难预约到,一定要提前预约",
                  Place_time: "9:00-17:00"
                },
                {
                  Place_id: 3,
                  Place_name: "虎丘",
                  Place_tickets: "旺季80元；淡季60元",
                  Place_traffic: "游2路虎丘站",
                  Place_lightspot: "吴中第一名胜",
                  Place_tips: null,
                  Place_time: "7:30-17:30",
                },
                {
                  Place_id: 4,
                  Place_name: "狮子林",
                  Place_tickets: "旺季30元；淡季40元",
                  Place_traffic: "游1、 3路",
                  Place_lightspot: "被称为'假山王国 '",
                  Place_tips: null,
                  Place_time: "全天",
                },
      
              ],
      
              //美食
              Foods: [{
                  Foods_id: 1,
                  Foods_name: "苏州点心",
                  Foods_price: "null",
                  Foods_place: "黄天源(酒酿饼)、万福兴(炒肉团子)、荣阳楼、明月楼",
                },
                {
                  Foods_id: 2,
                  Foods_name: "苏式面",
                  Foods_price: "null",
                  Foods_place: "裕兴记、同得兴、伟记奥面馆、陆长兴",
                },
                {
                  Foods_id: 3,
                  Foods_name: "蟹壳黄",
                  Foods_price: "null",
                  Foods_place: "潘记隆烧饼、王氏林记烧饼"
                },
                {
                  Foods_id: 4,
                  Foods_name: "泡泡馄饨",
                  Foods_price: "null",
                  Foods_place: "老西白点心店、陈记馄饨、乐惠馄饨"
                },
              ]
            },
            //4、天津
            {
              //城市编号
              City_id: 4,
              //城市名称
              City_name: "天津",
              status: 0,
              imgSrc:"../../images/p-1.jpg",
              // 背景大图
              bigimgSrc:"../../images/p-2.jpg",
              //推荐路线
              Reference: [{
                  Ref_id: 1,
                  Ref_cont: "世纪钟广场——津湾广场——意大利风情街——古文化街——南市食品街",
                },
                {
                  Ref_id: 2,
                  Ref_cont: "五大道——西开教堂——瓷房子——滨江道步行街——天津之眼",
                },
                {
                  Ref_id: 3,
                  Ref_cont: "天津博物馆——民国物语博物馆——静园——劝业场",
                },
                {
                  Ref_id: 4,
                  Ref_cont: "天津大学——南开大学——谦祥益相声茶馆/名流茶馆/西岸相声剧场",
                },
              ],
              //旅游景点
              Places: [{
                  Place_id: 1,
                  Place_name: "五大道景区及小白楼",
                  Place_tickets: "免费",
                  Place_traffic: "地铁1号线小白楼站下",
                  Place_lightspot: "曾经为英租界,遗留的众国风貌建筑变成了一道亮丽的风景线",
                  Place_tips: null,
                  Place_time: "全天",
                },
                {
                  Place_id: 2,
                  Place_name: "瓷房子",
                  Place_tickets: "50元",
                  Place_traffic: "1/9/35路公交山东路站下车,步行200米",
                  Place_lightspot: "一座用多件古董装饰而成的法式洋楼,房主张连志自己设计,用其多年收藏的古瓷器、汉白玉雕、玛瑙、水晶作为装修材料",
                  Place_tips: "null",
                  Place_time: "9:00-18:00"
                },
                {
                  Place_id: 3,
                  Place_name: "天主教堂西开总堂",
                  Place_tickets: "免费",
                  Place_traffic: "35/50/606路公交在滨江道站下",
                  Place_lightspot: "是天津市最大的天主教堂,整个建筑是法式的罗曼风",
                  Place_tips: null,
                  Place_time: "平日6:00、7:30各一台；主日6:00、7:30、10:00、11:30各一台",
                },
                {
                  Place_id: 4,
                  Place_name: "意大利风情街",
                  Place_tickets: "免费",
                  Place_traffic: "乘坐5/8/27/634/638等公交可以直达",
                  Place_lightspot: "《南京！南京！》等电影的拍摄地,另外在意大利老租界里,梁启超的饮冰室、曹禺故居、李叔同故居、袁世凯以及冯国璋府邸等旧居都在",
                  Place_tips: null,
                  Place_time: "全天",
                },
                {
                  Place_id: 5,
                  Place_name: "天津之眼(永乐桥摩天轮)",
                  Place_tickets: "70元",
                  Place_traffic: "乘坐34/4/607/802等公交到五马路站下",
                  Place_lightspot: "世界上唯一建在桥上的摩天轮。最高处可达到120米左右,相当于35层楼高度,能看到方圆40公里内的景致",
                  Place_tips: null,
                  Place_time: "9:30-21:30",
                },
              ],
      
              //美食
              Foods: [{
                  Foods_id: 1,
                  Foods_name: "包子",
                  Foods_price: "null",
                  Foods_place: "永胜包子铺、津门张记包子、陈傻子包子、老陶包子铺",
                },
                {
                  Foods_id: 2,
                  Foods_name: "煎饼果子",
                  Foods_price: "null",
                  Foods_place: "南楼煎饼、杨姐煎饼果子、红姐煎饼果子、二嫂子煎饼果子",
                },
                {
                  Foods_id: 3,
                  Foods_name: "锅巴菜、老豆腐",
                  Foods_price: "null",
                  Foods_place: "陈记锅巴菜、大福来锅巴菜、罗锅老豆腐"
                },
                {
                  Foods_id: 4,
                  Foods_name: "麻花",
                  Foods_price: "3-5元",
                  Foods_place: "桂发祥十八街麻花、桂顺斋"
                },
              ]
            },
            //5、北京
            {
              //城市编号
              City_id: 5,
              //城市名称
              City_name: "北京",
              status: 0,
              imgSrc:"../../images/p-1.jpg",
              // 背景大图
              bigimgSrc:"../../images/p-2.jpg",
              //推荐路线
              Reference: [{
                  Ref_id: 1,
                  Ref_cont: "南锣鼓巷——烟袋斜街——什刹海——北海——护国寺小吃",
                },
                {
                  Ref_id: 2,
                  Ref_cont: "八达岭长城/十三陵",
                },
                {
                  Ref_id: 3,
                  Ref_cont: "天安门广场——国家博物院——天坛——王府井",
                },
                {
                  Ref_id: 4,
                  Ref_cont: "故宫博物院——景山公园",
                },
                {
                  Ref_id: 5,
                  Ref_cont: "颐和园——圆明园——清华/北大",
                },
              ],
              //旅游景点
              Places: [{
                  Place_id: 1,
                  Place_name: "故宫",
                  Place_tickets: "淡季40元/人；旺季60元/人",
                  Place_traffic: "地铁1号线天安门东/西站",
                  Place_lightspot: "故宫",
                  Place_tips: null,
                  Place_time: "旺季8:30-17:00;淡季:8:00-16:30;周一闭馆,法定节假日",
                },
                {
                  Place_id: 2,
                  Place_name: "八达岭长城",
                  Place_tickets: "淡季40元,旺季45元",
                  Place_traffic: "地铁2号线积水潭站下,前往德胜门乘877路公交直达八达岭长城脚下,车程约1小时",
                  Place_lightspot: "中国古代伟大的防御工程万里长城的重要组成部分,是明长城的一个隘口",
                  Place_tips: "null",
                  Place_time: "淡季6:00-19:00;旺季7:00-18:00"
                },
                {
                  Place_id: 3,
                  Place_name: "天坛公园",
                  Place_tickets: "15元",
                  Place_traffic: "地铁5号线天坛东门站A1口(东门)",
                  Place_lightspot: "天坛是明、清两朝皇帝祭天、求雨和祈祷丰年的专用祭坛,是全国著名的古建筑",
                  Place_tips: null,
                  Place_time: "6:00-21:00",
                },
                {
                  Place_id: 4,
                  Place_name: "颐和园",
                  Place_tickets: "旺季30元",
                  Place_traffic: "地铁4号线北宫门站D出口",
                  Place_lightspot: "保存最完整的一座皇家行宫御苑,被称为'皇家园林博物馆'",
                  Place_tips: null,
                  Place_time: "6:00-18:00",
                },
                {
                  Place_id: 5,
                  Place_name: "圆明园",
                  Place_tickets: "10元",
                  Place_traffic: "地铁4号线圆明园南门站C口",
                  Place_lightspot: "19世纪末遭英法联军劫掠和焚毁,沦为一片废墟",
                  Place_tips: null,
                  Place_time: "7:00-20:30",
                },
              ],
              //美食
              Foods: [{
                  Foods_id: 1,
                  Foods_name: "北京烤鸭",
                  Foods_price: "null",
                  Foods_place: "四季民福烤鸭店、便宜坊、全聚德",
                },
                {
                  Foods_id: 2,
                  Foods_name: "铜锅涮肉",
                  Foods_price: "null",
                  Foods_place: "聚宝源、金生隆、南门涮肉、牛街清真满恒记、天桥老街涮肉、东来顺",
                },
                {
                  Foods_id: 3,
                  Foods_name: "炸酱面",
                  Foods_price: "null",
                  Foods_place: "方砖厂69号炸酱面、海碗居、菊儿人家、新成炸酱面馆"
                },
                {
                  Foods_id: 4,
                  Foods_name: "卤煮火烧",
                  Foods_price: "null",
                  Foods_place: "门框胡同百年卤煮、北新桥卤煮老店、护国寺小吃"
                },
              ]
            },
            //6、杭州
            {
              //城市编号
              City_id: 6,
              status: 0,
              //城市名称
              City_name: "杭州",
              imgSrc:"../../images/p-1.jpg",
              // 背景大图
              bigimgSrc:"../../images/p-2.jpg",
              //推荐路线
              Reference: [{
                  Ref_id: 1,
                  Ref_cont: "西湖一日游(湖滨公园——断桥——白堤——苏堤——花港观鱼——太子湾公园——雷锋塔）",
                },
                {
                  Ref_id: 2,
                  Ref_cont: "京杭大运河——水上巴士——拱宸桥——小河直街",
                },
                {
                  Ref_id: 3,
                  Ref_cont: "浙江省博物馆——浙江大学之江校区——白塔公园",
                },
                {
                  Ref_id: 4,
                  Ref_cont: "西塘古街一日游/千岛湖一日游——杭州",
                },
                {
                  Ref_id: 5,
                  Ref_cont: "法喜寺——中国美术学院象山校区",
                },
              ],
              //旅游景点
              Places: [{
                  Place_id: 1,
                  Place_name: "西湖风景名胜区",
                  Place_tickets: "null",
                  Place_traffic: "乘船",
                  Place_lightspot: "西湖山水包括一山、二塔、三岛、西湖十景、环湖街道",
                  Place_tips: null,
                  Place_time: "null",
                },
                {
                  Place_id: 2,
                  Place_name: "西湖腹地部分景点",
                  Place_tickets: "null",
                  Place_traffic: "0-8元",
                  Place_lightspot: "null",
                  Place_tips: "null",
                  Place_time: "全天"
                },
                {
                  Place_id: 3,
                  Place_name: "清河坊历史文化区",
                  Place_tickets: "免费",
                  Place_traffic: "null",
                  Place_lightspot: "南宋时杭州城政治文化经济中心,明清风格的建筑",
                  Place_tips: null,
                  Place_time: "全天",
                },
                {
                  Place_id: 4,
                  Place_name: "京杭大运河",
                  Place_tickets: "3元",
                  Place_traffic: "可在武林码头乘坐水上巴士",
                  Place_lightspot: "南起杭州,北至北京,世界上工程最大的古代运河",
                  Place_tips: null,
                  Place_time: "全天",
                },
                {
                  Place_id: 5,
                  Place_name: "乌镇",
                  Place_tickets: "东栅120元；西栅150元",
                  Place_traffic: "高铁至桐乡转乌镇,或者杭州九堡客运中心大巴至乌镇",
                  Place_lightspot: "历史文化名镇,江南水乡,电影《似水年华》取景地",
                  Place_tips: null,
                  Place_time: "全天",
                },
              ],
      
              //美食
              Foods: [{
                  Foods_id: 1,
                  Foods_name: "西湖醋鱼",
                  Foods_price: "null",
                  Foods_place: "西湖国宾馆、杭州酒家、楼外楼、四季酒店",
                },
                {
                  Foods_id: 2,
                  Foods_name: "龙井虾仁",
                  Foods_price: "null",
                  Foods_place: "杭州酒家、绿茶餐厅",
                },
                {
                  Foods_id: 3,
                  Foods_name: "杭州小笼",
                  Foods_price: "null",
                  Foods_place: "新丰小吃、知味观"
                },
                {
                  Foods_id: 4,
                  Foods_name: "片儿川",
                  Foods_price: "null",
                  Foods_place: "菊英面馆、方老大面、福缘居、复兴面王"
                },
                {
                  Foods_id: 5,
                  Foods_name: "猫耳朵",
                  Foods_price: "null",
                  Foods_place: "知味观"
                },
                {
                  Foods_id: 6,
                  Foods_name: "藕粉",
                  Foods_price: "null",
                  Foods_place: "佳藕天成"
                },
              ]
            },
            //7、青岛
            {
              //城市编号
              City_id: 7,
              status: 0,
              //城市名称
              City_name: "青岛",
              imgSrc:"../../images/p-1.jpg",
              // 背景大图
              bigimgSrc:"../../images/p-2.jpg",
              //推荐路线
              Reference: [{
                  Ref_id: 1,
                  Ref_cont: "八大关——第二海水浴场——栈桥——海军博物馆——鲁迅公园——小青岛——中山路",
                },
                {
                  Ref_id: 2,
                  Ref_cont: "天主教堂——江苏路基督教堂——信号山公园——德国监狱旧址博物馆——青岛邮电博物馆",
                },
                {
                  Ref_id: 3,
                  Ref_cont: "中国海洋大学鱼山校区——大学路——鱼山路——中山公园——奥帆中心——五四广场",
                },
                {
                  Ref_id: 4,
                  Ref_cont: "小麦岛——燕儿岛公园——营口路海鲜市场",
                },
                {
                  Ref_id: 5,
                  Ref_cont: "崂山一日游(清流——太清宫——华严寺——仰口）",
                },
              ],
              //旅游景点
              Places: [{
                  Place_id: 1,
                  Place_name: "栈桥",
                  Place_tickets: "免费",
                  Place_traffic: "2/5/801公交栈桥公园站",
                  Place_lightspot: "全球闻名的青岛啤酒的标签上,印着的就是与青岛同龄的栈桥,长长的线条直升海里",
                  Place_tips: null,
                  Place_time: "全天",
                },
                {
                  Place_id: 2,
                  Place_name: "浙江路天主教堂",
                  Place_tickets: "10元",
                  Place_traffic: "地铁3号线到青岛站",
                  Place_lightspot: "即'圣弥艾尔大教堂 ',中国唯一祝圣教堂,青岛最大哥特式教堂",
                  Place_tips: "null",
                  Place_time: "8:00-17:00(周一-S周六)"
                },
                {
                  Place_id: 3,
                  Place_name: "奥林匹克帆船中心",
                  Place_tickets: "免费",
                  Place_traffic: "208环线/210眼科医院站",
                  Place_lightspot: "08年北京奥运会和13届残奥会帆船比赛举行地,最能体现'帆船之都 '青岛特色和城市风貌的景点",
                  Place_tips: null,
                  Place_time: "5:00-23:00",
                },
                {
                  Place_id: 4,
                  Place_name: "五四广场",
                  Place_tickets: "免费",
                  Place_traffic: "25/316等公交市政府下车",
                  Place_lightspot: "青岛最具标志性的广场。广场中心著名雕塑'五月的风',庄重、坚实、蓬勃向上",
                  Place_tips: null,
                  Place_time: "全天",
                },
                {
                  Place_id: 5,
                  Place_name: "信号山公园",
                  Place_tickets: "15元",
                  Place_traffic: "228、225等路车在青医院站下",
                  Place_lightspot: "山顶三栋红顶蘑菇楼极为明显,这里可以360度俯瞰青岛的景色,包括十景之一'红楼暮霞'",
                  Place_tips: null,
                  Place_time: "7:00-17:30",
                },
              ],
      
              //美食
              Foods: [{
                  Foods_id: 1,
                  Foods_name: "海鲜和鲁菜",
                  Foods_price: "null",
                  Foods_place: "九龙餐厅浙江路11号甲",
                },
                {
                  Foods_id: 2,
                  Foods_name: "海鲜水饺",
                  Foods_price: "null",
                  Foods_place: "船歌鱼水饺、开海",
                },
              ]
            },
            //8、重庆
            {
              //城市编号
              City_id: 8,
              status: 0,
              //城市名称
              City_name: "重庆",
              imgSrc:"../../images/p-1.jpg",
              // 背景大图
              bigimgSrc:"../../images/p-2.jpg",
              //推荐路线
              Reference: [{
                  Ref_id: 1,
                  Ref_cont: "解放碑——洪崖洞——弹子石老街",
                },
                {
                  Ref_id: 2,
                  Ref_cont: "中山四路——长江索道——白象街",
                },
                {
                  Ref_id: 3,
                  Ref_cont: "李子坝——鹅岭二厂——三峡博物馆——涂鸦一条街",
                },
              ],
              //旅游景点
              Places: [{
                  Place_id: 1,
                  Place_name: "解放碑",
                  Place_tickets: "免费",
                  Place_traffic: "轻轨2号线在临江门下车",
                  Place_lightspot: "是个纪念碑,也是重庆重要的商圈",
                  Place_tips: null,
                  Place_time: "全天",
                },
                {
                  Place_id: 2,
                  Place_name: "洪崖洞",
                  Place_tickets: "免费",
                  Place_traffic: "轻轨1号线在小什子站下车",
                  Place_lightspot: "现实版千与千寻,夜景是真的太美了",
                  Place_tips: "null",
                  Place_time: "全天"
                },
                {
                  Place_id: 3,
                  Place_name: "弹子石老街",
                  Place_tickets: "免费",
                  Place_traffic: "轻轨环线在弹子石站下车",
                  Place_lightspot: "看星河灯海的浪漫景观,夜景很美",
                  Place_tips: null,
                  Place_time: "全天",
                },
                {
                  Place_id: 4,
                  Place_name: "中山四路",
                  Place_tickets: "免费",
                  Place_traffic: "114公交车在清寺站下车",
                  Place_lightspot: "重庆最美街道,《少年的你》取景地",
                  Place_tips: null,
                  Place_time: "全天",
                },
                {
                  Place_id: 5,
                  Place_name: "长江索道",
                  Place_tickets: "单程20元；往返30元",
                  Place_traffic: "轻轨环线外环在上新街站下车",
                  Place_lightsport: "体验山城独特的交通方式,肖战《奇妙之城》同款",
                  Place_tips: null,
                  Place_time: "全天",
                },
              ],
      
              //美食
              Foods: [{
                  Foods_id: 1,
                  Foods_name: "火锅",
                  Foods_price: "null",
                  Foods_place: "朱氏胖子烂火锅、邓记莽子老火锅、矿火锅、大龙火锅",
                },
                {
                  Foods_id: 2,
                  Foods_name: "重庆小面",
                  Foods_price: "null",
                  Foods_place: "花市豌杂面、惠氏抄手面、十八梯眼镜面、胖妹面庄",
                },
                {
                  Foods_id: 3,
                  Foods_name: "烧烤",
                  Foods_price: "null",
                  Foods_place: "30度街吧",
                },
                {
                  Foods_id: 4,
                  Foods_name: "特色品牌店老字号/连锁",
                  Foods_price: "40-90不等",
                  Foods_place: "山城羊肉馆、顺风123、小天鹅火锅、乡村基、齐齐药膳火锅",
                },
              ]
            },
            //9、西安
            {
              //城市编号
              City_id: 9,
              status: 0,
              //城市名称
              City_name: "西安",
              imgSrc:"../../images/p-1.jpg",
              // 背景大图
              bigimgSrc:"../../images/p-2.jpg",
              //推荐路线
              Reference: [{
                  Ref_id: 1,
                  Ref_cont: "钟鼓楼——西安古城墙——碑林博物馆——永兴坊——回民街",
                },
                {
                  Ref_id: 2,
                  Ref_cont: "兵马俑一日游(兵马俑——华清宫——骊山)",
                },
                {
                  Ref_id: 3,
                  Ref_cont: "陕西历史博物馆——大雁塔——大慈恩寺遗址公园——大唐芙蓉园——大唐不夜城",
                },
                {
                  Ref_id: 4,
                  Ref_cont: "华山一日游",
                },
                {
                  Ref_id: 5,
                  Ref_cont: "书院门——曲江书城——小寨寨格",
                },
              ],
              //旅游景点
              Places: [{
                  Place_id: 1,
                  Place_name: "古城墙",
                  Place_tickets: "54",
                  Place_traffic: "地铁2号线永宁门站A1口",
                  Place_lightspot: "中国现存最完整的一座古代恒城建筑,至今已有1400余年历史,可以在城墙上骑单车",
                  Place_tips: null,
                  Place_time: "8:00-21:30",
                },
                {
                  Place_id: 2,
                  Place_name: "钟楼/鼓楼",
                  Place_tickets: "35元",
                  Place_traffic: "地铁2号线鼓楼站",
                  Place_lightspot: "建于明代,至今已有两百年历史",
                  Place_tips: "null",
                  Place_time: "8:00-22:00"
                },
                {
                  Place_id: 3,
                  Place_name: "陕西历史博物馆",
                  Place_tickets: "免费",
                  Place_traffic: "地铁2号线小寨站D口",
                  Place_lightspot: "博物馆馆藏37万余件,浓缩了中华民族的历史精华,是展示中国古代文明和陕西省历史文化的艺术殿堂",
                  Place_tips: null,
                  Place_time: "9:00-17:30",
                },
                {
                  Place_id: 4,
                  Place_name: "大雁塔",
                  Place_tickets: "25元",
                  Place_traffic: "地铁4号线大雁塔站/3号线大雁塔北站",
                  Place_lightspot: "又名大慈恩寺塔,距今1300多年历史,西安标志性建筑之一",
                  Place_tips: null,
                  Place_time: "8:00-19:30",
                },
                {
                  Place_id: 5,
                  Place_name: "秦始皇兵马俑博物馆",
                  Place_tickets: "120元",
                  Place_traffic: "地铁1号线纺织城站A口,换游5旅游专线(306路)",
                  Place_lightsport: "无与伦比的地下军阵",
                  Place_tips: null,
                  Place_time: "8:30-18:00",
                },
                {
                  Place_id: 6,
                  Place_name: "华清宫",
                  Place_tickets: "120元",
                  Place_traffic: "306公交",
                  Place_lightsport: "因杨贵妃名扬天下,自古是皇家游览沐浴圣地",
                  Place_tips: null,
                  Place_time: "7:00-19:00",
                },
              ],
      
              //美食
              Foods: [{
                  Foods_id: 1,
                  Foods_name: "肉夹馍",
                  Foods_price: "20+",
                  Foods_place: "子午路张记肉夹馍",
                },
                {
                  Foods_id: 2,
                  Foods_name: "甑糕",
                  Foods_price: "10元",
                  Foods_place: "东南亚甑糕",
                },
                {
                  Foods_id: 3,
                  Foods_name: "油茶麻花",
                  Foods_price: "10元",
                  Foods_place: "回民街",
                },
                {
                  Foods_id: 4,
                  Foods_name: "羊肉泡馍",
                  Foods_price: "20+",
                  Foods_place: "景德牛羊肉泡馍",
                },
              ]
            },
            //10、成都
            {
              //城市编号
              City_id: 10,
              status: 0,
              //城市名称
              City_name: "成都",
              imgSrc:"../../images/p-1.jpg",
              // 背景大图
              bigimgSrc:"../../images/p-2.jpg",
              //推荐路线
              Reference: [{
                  Ref_id: 1,
                  Ref_cont: "人们公园——宽窄巷子——武侯祠——锦里——奎星楼街",
                },
                {
                  Ref_id: 2,
                  Ref_cont: "春熙路太古里——四川大学望江校区——望江楼公园——九眼桥",
                },
                {
                  Ref_id: 3,
                  Ref_cont: "成都大熊猫繁育基地——杜甫草堂——浣花溪公园",
                },
                {
                  Ref_id: 4,
                  Ref_cont: "青城山都江堰一日游",
                },
                {
                  Ref_id: 5,
                  Ref_cont: "青羊宫/文殊院——建设路小吃街",
                },
              ],
              //旅游景点
              Places: [{
                  Place_id: 1,
                  Place_name: "宽窄巷子",
                  Place_tickets: "免费",
                  Place_traffic: "地铁2号线人民公园站",
                  Place_lightspot: "由宽巷子、窄巷子、井巷子平行排列组成,全为青黛瓦砖的仿古四合院落,这里也是成都遗留下来的较成规模的清朝古街道,与大慈寺、文殊院一起并称为成都三大历史文化名城保护街",
                  Place_tips: null,
                  Place_time: "全天",
                },
                {
                  Place_id: 2,
                  Place_name: "武侯祠",
                  Place_tickets: "60元",
                  Place_traffic: "1/58/335武侯祠站；8/21路武侯祠东街站",
                  Place_lightspot: "始建于章武元年,原是纪念诸葛亮的专祠,亦称为孔明庙、诸葛祠、丞相祠,后合并为君臣合祀祠庙",
                  Place_tips: "null",
                  Place_time: "8:00-18:00"
                },
                {
                  Place_id: 3,
                  Place_name: "成都大熊猫繁育基地",
                  Place_tickets: "58元",
                  Place_traffic: "地铁3号线熊猫大道转战熊猫快线",
                  Place_lightspot: "是中国政府实施大熊猫等濒危野生动物迁地保护工程的主要研究基地之一,国家AAAA级旅游景区 ",
                  Place_tips: null,
                  Place_time: "8:00-18:00",
                },
                {
                  Place_id: 4,
                  Place_name: "锦里",
                  Place_tickets: "免费",
                  Place_traffic: "1/57/58/335至武侯祠站",
                  Place_lightspot: "以明末清初川西居民作外衣,三国文化与成都民俗作为内涵,集旅游购物、休闲娱乐为一体",
                  Place_tips: null,
                  Place_time: "全天",
                },
                {
                  Place_id: 5,
                  Place_name: "人民公园",
                  Place_tickets: "免费",
                  Place_traffic: "地铁1号线到天府广场站",
                  Place_lightsport: "公园集园林、文化、文物保护、爱国主义教育、休闲娱乐于一体的综合性公园",
                  Place_tips: null,
                  Place_time: "全天",
                },
                {
                  Place_id: 6,
                  Place_name: "春熙路",
                  Place_tickets: "免费",
                  Place_traffic: "地铁2号线春熙路站",
                  Place_lightsport: "春熙路热闹繁华,现大约有商业网点700家,被业内誉为中国特色商业街",
                  Place_tips: null,
                  Place_time: "全天",
                },
                {
                  Place_id: 7,
                  Place_name: "青城山",
                  Place_tickets: "前山90元；后山20元；白云索道上行35元；下行30元；往返60元",
                  Place_traffic: "地铁2号线至犀浦站,犀浦站到青城山(票价10元,车程约30分钟)",
                  Place_lightsport: "世界文化遗产-都江堰主体景区、全国重点文物保护单位、国家重点风景名胜区",
                  Place_tips: null,
                  Place_time: "8:00-18:00",
                },
                {
                  Place_id: 8,
                  Place_name: "都江堰",
                  Place_tickets: "80元门票；观光车往返15元",
                  Place_traffic: "犀浦站-都江堰(票价10元车程30分钟)",
                  Place_lightsport: "世界文化遗产、世界灌溉工程遗产、全国重点文物保护单位",
                  Place_tips: null,
                  Place_time: "8:00-18:00",
                },
              ],
              //美食
              Foods: [{
                  Foods_id: 1,
                  Foods_name: "火锅",
                  Foods_price: "null",
                  Foods_place: "电台巷火锅、蜀九香火锅、小龙坎火锅、大龙燚火锅、川西坝子",
                },
                {
                  Foods_id: 2,
                  Foods_name: "串串",
                  Foods_price: "null",
                  Foods_place: "冒椒火辣、马路边边麻辣烫、小郡肝串串香、无名冒菜",
                },
                {
                  Foods_id: 3,
                  Foods_name: "手撕烤兔/麻辣兔头",
                  Foods_price: "null",
                  Foods_place: "王妈手撕烤兔、老黄及手撕烤兔",
                },
                {
                  Foods_id: 4,
                  Foods_name: "糖油果子",
                  Foods_price: "null",
                  Foods_place: "杨师傅糖油果子、邓记新一代糖油果子",
                },
                {
                  Foods_id: 5,
                  Foods_name: "红糖糍粑",
                  Foods_price: "null",
                  Foods_place: "李记冰粉糍粑",
                },
              ]
            },
          ]
    },

    aimInput:function(e){
        var that = this;
        if(e.detail.value == ""){
            that.setData({
                history: true,
                aimList: true
            })
            for(var index in that.data.cityList){
                let temp = "cityList[" + index + "].status";
                that.setData({
                    [temp]:0,
                })
            }
        }
        that.setData({
            aimText:e.detail.value
        })
    },

    search:function(e){
        var that = this;
        var searchtext = that.data.aimText;
        var s = true;//未找到提示
        if (searchtext ==""){
            that.setData({
                noneview:true,//未找到
                searchRes:false,//搜索到的列表
                aimList:true,//隐藏目的地列表
                history:false//隐藏历史记录
            })
        }
        else{
            that.data.historyArry.push(searchtext);
            for(var index in that.data.cityList){
                var num = that.data.cityList[index].City_name.indexOf(searchtext);
                let temp = "cityList[" +index + "].status";
                if (num != -1){
                    that.setData({
                        [temp]:1,
                    })
                    s=false
                }
            }
            that.setData({
                history:false,
                noneview:s,
                aimList:true,
                searchRes:true,
                newArry:this.data.historyArry
            })
        }
    },
    cleanhistory:function(e){
        this.setData({
            history:false,
            historyArry:[],
            newArry:[],
        })
    },

    historyText:function(e){
        var that = this;
        that.setData({
            aimText:e.target.dataset.text
        })
    },
})