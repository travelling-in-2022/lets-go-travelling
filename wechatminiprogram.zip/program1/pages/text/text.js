// index.js
const innerAudioContext=wx.createInnerAudioContext()
Page({
  data: {
    mainText: ''
  },
  goto:function(){
    wx.redirectTo({
      url: '../../pages/review/review',
    })({
      url: '../../pages/review/review',
    })
  },
  onLoad(option) {
    const mainText=option.maintext||this.data.mainText;
    this.setData({
      mainText
    });
  },
  toMainTextInput(e) {
    const {value}=e.detail
    this.setData ({
      mainText: value
    });
  },//bindinput="toMainTextInput"
  play:function(e){
    console.log(this.data)
    var disry=this.data.mainText
    wx.request({
      method:'POST',
      url: 'http://127.0.0.1:3000/apis/add', 
      data: {
        disry
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success:function(res){
          console.log(res.data)
      }
    })
  },

  formSubmit(e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value)
    const{mainText}=this.data;
    return {
      title: 'form',
      path: `pages/text/text?maintext=${mainText}`
    }
  },

  //定义分享
  onShareAppMessage() {
    const{mainText}=this.data;
    return {
      title: 'form',
      path: `pages/text/text?maintext=${mainText}`
    }
  },
})
