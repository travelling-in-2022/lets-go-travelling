Page({
 
  /**
   * 页面的初始数据
   */
  data: {
    id:'',
    pwd:''
  },
  
  /**
   * 生命周期函数--监听页面加载
   */
  onLoad: function (options) {
    /*const id=option.ID||this.data.id;
    const pwd=option.Pwd||this.data.pwd;
    this.setData({
      id,
      pwd
    });   */ 
  },

  toIdInput(e){
    var a1 = e.detail.value;
    var a2=RegExp('^\-', 'g').exec(e.detail.value)
    var g=1;
    if(a2){
      g=-1;
    }
    var a3=parseFloat(a1.replace(/\D/g, '')) * g
    this.setData({
      id:a3
    })
  },

  /*toIdInput (e){
    const {value}=e.detail
    this.setData ({
      id: value
    });
  },*/

  toPwdInput(e){
    const {value}=e.detail
    this.setData ({
      pwd: value
    });
  },

  stringToChars:function(_s){
    _s = _s.replace(/(^\s*)|(\s*$)/g, "");
    var _r = "";
    for(var i=0;i<_s.length;i++){
        _r += i==0 ? _s.charCodeAt(i) : "|" + _s.charCodeAt(i);
    }
    return _r;
  },

  play1:function(e){
    console.log(this.data)
    var user=this.data.id
    var pwd=this.data.pwd
    wx.request({
      method:'POST',
      url: 'http://127.0.0.1:3000/api/reg', 
      //仅为示例，并非真实的接口地址
      data: {
        user,
        pwd
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded' // 默认值
      },
      success:function(res){
          console.log(res)
      }
    })
    wx.switchTab({
      url: '../../pages/login/login'
    })
  },

  play2:function(e){
    console.log(this.data)
    var user=this.data.id
    var pwd=this.data.pwd
    wx.request({
      method:'POST',
      url: 'http://127.0.0.1:3000/api/login', 
      //仅为示例，并非真实的接口地址
      data: {
        user,
        pwd
      },
      header: {
        'content-type': 'application/x-www-form-urlencoded'// 默认值
      },
      success:function(res){
          console.log(res.data)
      }
    })
    wx.switchTab({
      url: '../../pages/main/main'
    })
  },

  formSubmit(e) {
    console.log('form发生了submit事件，携带数据为：', e.detail.value)
    const{id,pwd}=this.data;
    return {
      title: 'form',
      path: `pages/login/login?ID=${id}&Pwd=${pwd}}`
    }
  },
 
  /**
   * 生命周期函数--监听页面初次渲染完成
   */
  onReady: function () {
    
  },
 
  /**
   * 生命周期函数--监听页面显示
   */
  onShow: function () {
    
  },
 
  /**
   * 生命周期函数--监听页面隐藏
   */
  onHide: function () {
    
  },
 
  /**
   * 生命周期函数--监听页面卸载
   */
  onUnload: function () {
    
  },
 
  /**
   * 页面相关事件处理函数--监听用户下拉动作
   */
  onPullDownRefresh: function () {
    
  },
 
  /**
   * 页面上拉触底事件的处理函数
   */
  onReachBottom: function () {
    
  },
 
  /**
   * 用户点击右上角分享
   */
  onShareAppMessage: function () {
    
  }
})