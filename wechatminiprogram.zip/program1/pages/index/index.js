// index.js
    var amapFile = require("../../libs/amap-wx.130");
    var markersData = [];

Page({
  data: {
    markers: [],
    latitude: '',
    longitude: '',
    textData: {}
  },
  makertap: function(e) {
    var id = e.markerId;
    var that = this;
    that.showMarkerInfo(markersData,id);
    that.changeMarkerColor(markersData,id);
  },
  onShareAppMessage: function () {
    const url = `pages/addition/addition`;
    return {
      title: "分享景点",
      path:url
    }
  },
  onLoad: function() {
    var that = this;
    var myAmapFun = new amapFile.AMapWX({key:'c31d64a77513e0c091051433435b3f76'});
    myAmapFun.getPoiAround({
      iconPathSelected: "../../images/星星.png", //如：..­/..­/img/marker_checked.png
      iconPath: "../../images/星星2.png", //如：..­/..­/img/marker.png
      success: function(data){
        markersData = data.markers;
        that.setData({
          markers: markersData
        });
        that.setData({
          latitude: markersData[0].latitude
        });
        that.setData({
          longitude: markersData[0].longitude
        });
        that.showMarkerInfo(markersData,0);
      },
      fail: function(info){
        wx.showModal({title:info.errMsg})
      }
    })
  },
  showMarkerInfo: function(data,i){
    var that = this;
    that.setData({
      textData: {
        name: data[i].name,
        desc: data[i].address
      }
    });
  },
  changeMarkerColor: function(data,i){
    var that = this;
    var markers = [];
    for(var j = 0; j < data.length; j++){
      if(j==i){
        data[j].iconPath = "../../images/星星.png"; //如：..­/..­/img/marker_checked.png
      }else{
        data[j].iconPath = "../../images/星星2.png"; //如：..­/..­/img/marker.png
      }
      markers.push(data[j]);
    }
    that.setData({
      markers: markers
    });
  }

})

